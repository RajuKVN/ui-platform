import * as React from 'react';
import * as TabsPrimitive from '@radix-ui/react-tabs';
import { cn } from '../../utils/cn';

const Tabs = TabsPrimitive.Root;

const TabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.List
    ref={ref}
    className={cn(
      [
        'inline-flex h-[var(--size-md)] items-center justify-center',
        'rounded-[var(--radius-lg)]',
        'bg-[var(--color-background-muted)]',
        'p-[var(--spacing-xs)]',
        'text-[var(--color-foreground-muted)]',
      ].join(' '),
      className
    )}
    {...props}
  />
));

TabsList.displayName = TabsPrimitive.List.displayName;

const TabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Trigger
    ref={ref}
    className={cn(
      [
        'inline-flex items-center justify-center whitespace-nowrap',
        'rounded-[var(--radius-md)]',
        'px-[var(--spacing-inline-md)] py-[var(--spacing-block-xs)]',
        'text-sm font-medium',
        'ring-offset-[var(--color-background)]',
        'transition-all',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-border-focus)] focus-visible:ring-offset-2',
        'disabled:pointer-events-none disabled:opacity-50',
        'data-[state=active]:bg-[var(--color-surface)]',
        'data-[state=active]:text-[var(--color-foreground)]',
        'data-[state=active]:shadow-[var(--shadow-sm)]',
      ].join(' '),
      className
    )}
    {...props}
  />
));

TabsTrigger.displayName = TabsPrimitive.Trigger.displayName;

const TabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn(
      [
        'mt-[var(--spacing-sm)]',
        'ring-offset-[var(--color-background)]',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-border-focus)] focus-visible:ring-offset-2',
      ].join(' '),
      className
    )}
    {...props}
  />
));

TabsContent.displayName = TabsPrimitive.Content.displayName;

export { Tabs, TabsList, TabsTrigger, TabsContent };
